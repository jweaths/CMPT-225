#include <iostream>
#include "BinarySearchTree.h"
using namespace std;

    // Test program
int main( )
{
    BinarySearchTree<int> t;
//    int NUMS = 400000;
    int NUMS = 10;
    const int GAP  = 3 ;
    const int CAP  = 19;
    int i;
    int key ;

    cout << "Start of Dtest" << endl << endl;

    key = CAP/2;
    for( i = 1 ; i <= NUMS ; i++ ){
        key = (key + GAP) % CAP ;
        t.insert( key );
    }

    if( NUMS < 40 ) {
        cout << "Keys:" << endl ;
        t.displayTree(); }
        cout << endl;
    
   
   	key = CAP/2;
    for( i = 1 ; i <= NUMS ; i++ ){
    
    key = (key + GAP) % CAP ;
  

	cout << "Depth of key " << key << ": " << t.depth( key ) << endl << endl;
    
    }
  

    cout << "End of Dtest" << endl;

    return 0;
}
