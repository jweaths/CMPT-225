#include <iostream>
#include <chrono>
#include <time.h>
#include "BinarySearchTree.h"
#include "AVLTree.h"

using namespace std::chrono;

double elapsed_time( clock_t start, clock_t finish){ // returns elapsed time in microseconds 
    return (finish - start)/(double)(CLOCKS_PER_SEC/1000000); 
} 


int main( )
{
    BinarySearchTree<int> binary;
    AvlTree<int> avl;
    
    int NUMS = 40000;
    const int GAP1  = 3 ; // for inserting
	const int GAP2 = 3 ; // for checking
    const int CAP  = 40000;
    int i;
    int key ;
    

   
   	cout << endl << "Start of Experiment 2" << endl << endl;

   
   
    double aCheckMin = 10000000000000;
    
    double aCheckMax = 0;
    
    double bCheckMin = 10000000000000;
    
    double bCheckMax = 0;
    
    double bDepthMin = 10000000000000;
    
    double bDepthMax = 0;
    
    double aDepthMin = 10000000000000;
    
    double aDepthMax = 0;

    double timeTaken, time1, time2, time3, time5; // for total time taken

    clock_t startClock1, stopClock1, startClock2, stopClock2, startClock3, stopClock3;
    
    clock_t startClock5, stopClock5; // time total functions
    
    clock_t start3, finish3, start5, finish5; // time    individual checks
    
    double theDepth;

    double totalDepth;

    double avgDepth;
   	
   	
   
   
   
    
    
    
    // mean binary
   
    
   
    startClock1 = clock() ; // starts clock
    key = CAP/2;
    for( i = 1 ; i <= NUMS ; i++ ){
        
        
        key = (key + GAP2) % CAP ;  // ensures every num is hit sequentially
        binary.insert( key ); // insert binary
          
       
        }
  
  	stopClock1 = clock() ;	// stops clock
    time1 = elapsed_time(startClock1, stopClock1) ;	// finds diff  
    time1 = time1 / CAP ;	// finds average
    
    
    
    cout << "BINARY TREE:" << endl;
    
    cout << "Height: "<< binary.height() << endl;
    
    
    // checking depth for binary
    
    
    key = CAP/2;
    for( i = 1 ; i <= NUMS ; i++ ) {
        
        
        key = (key + GAP1) % CAP ;  // increment
       
        
        theDepth = binary.depth( key ); // checks binary
        

        bDepthMin = min(theDepth, bDepthMin) ;
        bDepthMax = max(theDepth, bDepthMax) ;

        totalDepth += theDepth ;
        

    }

    avgDepth = totalDepth / NUMS ;
      
    
    cout << "Average depth: " << avgDepth << endl;
    cout << "Minimum depth: " << bDepthMin << endl;
    cout << "Maximum depth: " << bDepthMax
    << endl << endl ; // prints binary tree insertion time
    
   
    cout << "BINARY TIME TRIALS (MICROSECONDS): " << endl;
    
    
    cout << "Average insertion time: " << time1
    << endl ; // prints binary tree insertion time
   
 
 	
 	
 	

 	
   
   

    
    
    
    
    
    
    
    
    
    
    
    
    // checks binary

    

    
    
    startClock3 = clock() ; // starts clock
    
    key = CAP/2;
    for( i = 1 ; i <= NUMS ; i++ ) {
        
        
        key = (key + GAP1) % CAP ;  // increment
        
        

        start3 = clock() ; // starts clock for individual operations

        
        
        binary.contains( key ); // checks binary

        

        finish3 = clock() ;  // stops clock for individual operations
        
        
        timeTaken = elapsed_time(start3, finish3) ;  // finds the time one operation took
        

        bCheckMin = min(timeTaken, bCheckMin) ; // if timeTaken is less, new min

        bCheckMax = max(timeTaken, bCheckMax);  // if timeTaken is more, new max
        
        

    }
     
        
    stopClock3 = clock() ;	// stops clock
    time3 = elapsed_time(startClock3, stopClock3) ;	// finds diff  
    time3 = time3 / CAP ;	// finds average
    
    
    
    
    cout << "Average check time: " << time3 << endl;
    cout << "Minimum check time: " << bCheckMin << endl;
    cout << "Maximum check time: " << bCheckMax
    << endl << endl ; // prints binary tree insertion time
    
    
 
    
    
    
    // insert checking avl
    
    startClock2 = clock() ; // starts clock    
    key = CAP/2;
    for( i = 1 ; i <= NUMS ; i++ ){
        key = (key + GAP2) % CAP ;  // ensures every num is hit sequentially
        avl.insert( key ); // insert avl
        }
   	stopClock2 = clock() ;	// stops clock
    time2 = elapsed_time(startClock2, stopClock2) ;	// finds diff    
    time2 = time2 / CAP ;	// finds average   
    
  
    
     // checking depth for avl
    
    totalDepth = 0; // resets total depth

    key = CAP/2;
    for( i = 1 ; i <= NUMS ; i++ ) {
        
        
        key = (key + GAP1) % CAP ;  // increment
       
        
        theDepth = avl.depth( key ); // checks binary
        

        aDepthMin = min(theDepth, aDepthMin) ;
        aDepthMax = max(theDepth, aDepthMax) ;

        totalDepth += theDepth ;
        

    }

    avgDepth = totalDepth / NUMS ;
    
    
    cout << "AVL Tree:" << endl;
    
    cout << "Height: "<< avl.height() << endl;
    cout << "Average depth: " << avgDepth << endl;
    cout << "Minimum depth: " << aDepthMin << endl;
    cout << "Maximum depth: " << aDepthMax
    << endl << endl ; // prints binary tree insertion time
	


     
    // checks avl
    
    startClock5 = clock() ; // starts clock    
    key = CAP/2;
    for( i = 1 ; i <= NUMS ; i++ ){

        
        key = (key + GAP1) % CAP ;  // ensures every num is hit sequentially 

    


        	

            start5 = clock() ;

            

            avl.contains( key ) ; // checks binary

        

            finish5 = clock() ;
            
            
            timeTaken = elapsed_time(start5, finish5) ;
            
           
            aCheckMin = min(timeTaken, aCheckMin) ;

       		aCheckMax = max(timeTaken, aCheckMax);

   
    	
       
        
        }
        
        
   	stopClock5 = clock() ;	// stops clock
    time5 = elapsed_time(startClock5, stopClock5) ;	// finds diff    
    time5 = time5 / CAP ;	// finds average   
    

    

    cout << "AVL TIME TRIALS (MICROSECONDS): " << endl;
    
    cout << "Average insertion time: " << time2 << endl ;    
    cout << "Average check time: " << time5 << endl;
    cout << "Minimum check time: " << aCheckMin << endl;
    cout << "Maximum check time: " << aCheckMax 
    << endl << endl ; // prints binary tree insertion time
    






   
  
	cout << "End of Experiment 2" << endl << endl;
    
    
    
    
    
    if(NUMS <= 50) {
    // displaying trees if the tree is small enough
    cout << "Binary: " << endl;
    binary.displayTree() ;
    
 	cout << "AVL: " << endl;
    avl.displayTree() ;
    
 

    }

       
      
    }

