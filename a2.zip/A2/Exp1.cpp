#include <iostream>
#include <chrono>
#include "BinarySearchTree.h"

using namespace std::chrono;


int main( )
{
    BinarySearchTree<int> T1;
    BinarySearchTree<int> T2;


    int NUMS = 50000 ;
    const int GAP1  = 1 ; // iterates a long skinny tree
    const int GAP2 = 7 ; // iterates short and bushy tree
    const int CAP  = 50000 ;
    int i ;
    int key ;
    
    
    //DEPTH VARIABLES
    
    double bDepthMin = 10000000000000 ;
    
    double bDepthMax = 0 ;
    
    double aDepthMin = 10000000000000 ;
    
    double aDepthMax = 0 ;
    
    double theDepth;

    double totalDepth;

    double avgDepth;
   	


    cout << endl << "Start of Experiment 1" << endl << endl;

   
    // INSERTING T1
    key = 1;
    for( i = 1 ; i <= NUMS ; i++ ){
        key = key + GAP1;  // ensures every num is hit sequentially
        T1.insert( key ); // inserts long skinny
    }


	// INSERTING T2

	key = CAP/2;
	
    for( i = 1 ; i <= NUMS ; i++ ){
        
        key = (key + GAP2) % CAP ;  // iterates according to gap amd does not max out
        T2.insert( key );
    
    }
    
   
    // Checking T1 in terms of T2 and timing
    
    auto startClock1 = high_resolution_clock::now() ; // starts clock
    
	key = CAP/2;
    for( i = 1 ; i <= NUMS ; i++ ){
        
        key = (key + GAP2) % CAP ;  // checks T1 in order of T2 insertion
        T1.contains( key );
        
    }
    
    
    auto stopClock1 = high_resolution_clock::now() ;	// stops clock
    
    auto timeT1 = duration_cast<microseconds>( stopClock1 - startClock1) ;	// finds diff
    
    timeT1 = timeT1 / CAP ;	// finds average
    
    
    
    cout << "Tree T1:" << endl ;
    
    cout << endl << "Height: " << T1.height() << endl << endl;
    
    cout << "Average check time for T1 (Long and skinny): " << timeT1.count() 
    << " microseconds." << endl << endl ; // prints T1 time
    
    
     // checking depth for T1
    
        totalDepth = 0; // resets total depth
        
        key = 1;
    
      
        for( i = 1 ; i <= NUMS ; i++ ) {
        
        
         key = key + GAP1;
       
        
        theDepth = T1.depth( key ); // checks binary
        

        aDepthMin = min(theDepth, aDepthMin) ;
        aDepthMax = max(theDepth, aDepthMax) ;

        totalDepth += theDepth ;
        

    }

    avgDepth = totalDepth / NUMS ;
      
    
    cout << "Average depth of search: " << avgDepth 

    << endl << endl ; // prints T1 tree insertion time


        
    
    
    // Check T2 in terms of T1 and timing
    
    auto startClock2 = high_resolution_clock::now() ;  // starts clock  
    

	key = CAP/2;    // resets key
    
    for( i = 1 ; i <= NUMS ; i++ ){
        
        key = (key + GAP1) % CAP ;  // checks T2 in order of T1 insertion
        T2.contains( key );
        
    }
    
    
    auto stopClock2 = high_resolution_clock::now() ; // stops clock
    
    auto timeT2 = duration_cast<microseconds>( stopClock2 - startClock2) ; // finds diff

	timeT2 = timeT2 / CAP ; // finds average

	
	
	cout << "Tree T2:" << endl ;
    
    cout << endl << "Height: " << T2.height() << endl << endl;
   
	cout << "Average check time for T2 (Realistic): " << timeT2.count() 
	<< " microseconds." << endl << endl ; // prints T1 time
	
	
	// checking depth for T2
	
	key = CAP/2;
	
	totalDepth = 0;
	theDepth = 0; // resets depths
	avgDepth = 0;
    for( i = 1 ; i <= NUMS ; i++ ) {
        
        
        key = (key + GAP1) % CAP ;  // increment
       
        
        theDepth = T2.depth( key ); // checks binary
        

        bDepthMin = min(theDepth, bDepthMin) ;
        bDepthMax = max(theDepth, bDepthMax) ;

        totalDepth += theDepth ;
        

    }

    avgDepth = totalDepth / NUMS ;
      
    
    cout << "Average depth of search: " << avgDepth

    << endl << endl ; // prints binary tree insertion time
    

 


    cout << "End of Experiment 1" << endl << endl;

    return 0;
}
