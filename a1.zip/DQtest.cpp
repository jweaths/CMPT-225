#include "deque.h"
#include <iostream>
#include <cstring>
using namespace std;

int main( )

{

cout << endl;

Deque<int> intDeque; // Deque of type int
Deque<char> charDeque; // Deque of type char
string alphabet = "abcdefghijklmnopqrstuvwxyz" ; // string to fill char queue

///// TEST CASE 1 ///////////////////////////////////////////////

cout << "-------------------------------------------------------" << endl;
cout << "DEQUE BUILD 1: INT, Partially-Full, NO Index Wrapping." << endl; 
cout << "-------------------------------------------------------" << endl << endl;

// FILLING ARRAY / QUEUE -----------------------------------------------
for( int i = 0; i < intDeque.capacity() - 3; i++ ) // populates array
{

    intDeque.enqueue( i ) ;

}


// TESTING DISPLAY FUNCTIONS --------------------
cout << "intDeque Array: " << endl;
intDeque.ddisplay();
cout << endl;

cout << "intDeque Queue: " << endl;
intDeque.display();
cout << endl;


// TESTING EJECT FUNCTION -----------------------
cout << "intDeque Array after Eject: " << endl;
intDeque.eject(); 
intDeque.ddisplay();  
cout << endl;

cout << "intDeque Queue after Eject:" << endl;
intDeque.display(); 
cout << endl;

// TESTING JUMP FUNCTION -----------------------
cout << "intDeque Queue after Jump:" << endl;
int x = 100;
intDeque.jump( x );
intDeque.display();
cout << endl;

cout << "intDeque Array after Jump:" << endl;
intDeque.ddisplay();
cout << endl;


// TESTING CLEAR FUNCTION ---------------------
cout << "intDeque Array after Clear:" << endl;
intDeque.clear();
intDeque.ddisplay();
cout << endl;

cout << "intDeque Queue after Clear:" << endl;
intDeque.clear();
intDeque.display();
cout << endl;


///// TEST CASE 2 ////////////////////////////////////////////////////////

cout << "------------------------------------------------------------" << endl ;
cout << " DEQUE BUILD 2: CHAR, Partially-filled, NO Index Wrapping. " << endl ;
cout << "------------------------------------------------------------" << endl << endl;


// FILLING ARRAY / QUEUE -------------------------------------------------
for( int i = 0; i < charDeque.capacity() - 3; i++ )
{

    charDeque.enqueue(  alphabet[i] ) ;

}


// TESTING DISPLAY FUNCTIONS ---------------------------------------------
cout << "charDeque Array: " << endl;
charDeque.ddisplay();
cout << endl;

cout << "charDeque Queue: " << endl;
charDeque.display();
cout << endl;


// TESTING EJECT FUNCTION ------------------------------------------------
cout << "charDeque Array after Eject:" << endl;
charDeque.eject(); 
charDeque.ddisplay();  
cout << endl;

cout << "charDeque Queue after Eject:" << endl;
charDeque.display(); 
cout << endl;


// TESTING CLEAR FUNCTION -------------------------------------------------
cout << "charDeque Queue after Clear:" << endl;
charDeque.clear();
charDeque.display();
cout << endl;

cout << "charDeque Array after Clear:" << endl;
charDeque.clear();
charDeque.ddisplay();
cout << endl ;




///// TEST CASE 3 //////////////////////////////////////////////////////////
cout << "-----------------------------------------------------" << endl ;
cout << "DEQUE BUILD 3: TYPE INT, Full, WITH Index Wrapping." << endl ;
cout << "-----------------------------------------------------" << endl << endl;


// FILLING ARRAY / QUEUE -------------------------------------------------
for( int i = 0; i < intDeque.capacity(); i++ ) // populates array
{

    intDeque.enqueue( i ) ;

}

for( int i = 0; i < intDeque.capacity() / 2; i++ ) // dequeue half the elements
{

    intDeque.dequeue() ;

}

for( int i = 0; i < intDeque.capacity() / 2; i++ ) // populates array
{

    intDeque.enqueue( i ) ;

}

// TESTING DISPLAY FUNCTIONS -------------------------------------------------
cout << "intDeque Array: " << endl;
intDeque.ddisplay();
cout << endl;

cout << "intDeque Queue: " << endl;
intDeque.display();
cout << endl;

// TESTING EJECT FUNCTION -------------------------------------------------
cout << "intDeque Array after Eject: " << endl;
intDeque.eject(); 
intDeque.ddisplay();  
cout << endl;

cout << "intDeque Queue after Eject:" << endl;
intDeque.display(); 
cout << endl;


// TESTING JUMP FUNCTION -------------------------------------------------
cout << "intDeque Queue after Jump:" << endl;
x = 200;
intDeque.jump( x );
intDeque.display();
cout << endl;

cout << "intDeque Array after Jump:" << endl;
intDeque.ddisplay();
cout << endl;


// TESTING CLEAR FUNCTION -------------------------------------------------
cout << "intDeque Queue after Clear:" << endl;
intDeque.clear();
intDeque.display();
cout << endl;

cout << "intDeque Array after Clear: " << endl;
intDeque.ddisplay();
cout << endl;



///// TEST CASE 4 //////////////////////////////////////////////////////////
cout << "---------------------------------------------------" << endl ;
cout << "DEQUE BUILD 4: TYPE CHAR, Full, NO Index Wrapping." << endl ;
cout << "---------------------------------------------------" << endl << endl;


// FILLING ARRAY / QUEUE ---------------------------------------------------
for( int i = 0; i < charDeque.capacity(); i++ ) // populates array
{

    charDeque.enqueue( alphabet[i] ) ;

}


// TESTING DISPLAY FUCNTIONS ---------------------------------------------------
cout << "charDeque Array: " << endl;
charDeque.ddisplay();
cout << endl;

cout << "charDeque Queue: " << endl;
charDeque.display();
cout << endl;


// TESTING JUMP FUNCTION ---------------------------------------------------
//cout << "charDeque Array after Jump:" << endl;

cout << "charDeque Array after Jump:" << endl;
charDeque.jump( 'z' ) ;
charDeque.ddisplay() ;
cout << endl;

cout << "charDeque Queue after Jump:" << endl;
charDeque.display();
cout << endl;


// TESTING EJECT FUNCTION ---------------------------------------------------
cout << "charDeque Array after Eject: " << endl;
charDeque.eject(); 
charDeque.ddisplay();  
cout << endl;

cout << "charDeque Queue after Eject:" << endl;
charDeque.display(); 
cout << endl;


// TESTING RESERVE FUNCTION ---------------------------------------------------
cout << "charDeque Array after Reserve: " << endl;
int newCap = charDeque.capacity() * 2;
charDeque.reserve( newCap ); 
charDeque.ddisplay();  
cout << endl;

cout << "charDeque Queue after Reserve:" << endl;
charDeque.display(); 
cout << endl;


// TESTING CLEAR FUNCTON ---------------------------------------------------
cout << "charDeque Queue after Clear:" << endl;
charDeque.clear();
charDeque.display();
cout << endl;

cout << "charDeque Array after Clear: " << endl;
charDeque.ddisplay();
cout << endl;




return 0;

}
