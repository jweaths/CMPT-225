#ifndef DEQUE_H
#define DEQUE_H

#include <iostream>
using namespace std;

template <typename Object>
class Deque 
{
  public:
    Deque() // constructor
      {  
         
         theCapacity = 8 ;
         objects = new Object[ theCapacity ] ; 
         theSize = 0 ;
         front = 0 ; 
         back = 0 ;
         reserved = 0 ;

      }
      
    ~Deque( ) // destructor
      { 
        
        delete [ ] objects ; 
        
        }

    bool empty( ) const  { //checks if the queue is empty
      
      return size( ) == 0 ; 
      
      } 
    
    int size( ) const { // gets size of the queue
      
       return theSize ; 
       
       } 
    
    int capacity( ) const {

      return theCapacity ;

    }

    Object & operator[] (int dequeIndex ) // operator definition for assigning index
    {

      if ( dequeIndex < 0 || dequeIndex >= theSize ) 
      {
        cout << "Out of bounds Deque Index was assigned." << endl ;

      }

      return objects[ ( front + dequeIndex ) % theCapacity] ;


    }

    const  Object & operator[] (int dequeIndex ) const // operator definition for calling index
    {

      if ( dequeIndex < 0 || dequeIndex >= theSize ) 
      {
        cout << "Out of bounds Deque Index was called." << endl ;

      }

      return objects[ ( front + dequeIndex )  % theCapacity] ;

    }


    void clear( ) {
        
        // remove all contents and reset the capacity to it's initial value 
        // Implement
        

        int i = 0 ;

        while( i <= theCapacity ) { // empties array contents
          
          
          
            objects[i] = 0 ; // fills with zeros

            i++ ;

        }

        front = 0 ; // resets values
        back = 0 ;
        theSize = 0 ;
        theCapacity -= reserved ; // decreased theCapacity by reserved amount, resetting
      
        

    }

    void reserve( int newCapacity )
    {
        // change the capacity to newCapacity 
        // (provided it is larger than the current size)
        // 
        // Implement

        if( newCapacity < theCapacity )
        {

            return ; // returns if theCapacity is bigger than the desired

        }
        

        Object* catalyst = new Object[newCapacity] ; // creates empty array with larger capacity
        
        

        swap(objects, catalyst) ;  // swaps arrays

        int i = front ;  // sets index to the front
        int j = 0 ; // size tracker

        
        
        while(j < theSize)
        {

            
            objects[j] = catalyst[i] ; // enqueues object starting from 0 (no wrapping)

            

            i = (i + 1) % theCapacity; // incrementing i modularily (old array)
            j++ ; // incrementing j linerily (new array)

        }

       

        int increase = newCapacity - theCapacity ;
              
        reserved += increase ; // calculates and notes extra space requested
        
        theCapacity = newCapacity ; // sets the newCapacity
        

        front = 0 ; // sets new front
        back = theSize ; // sets new back   

        delete [ ] catalyst ; // deletes old swapped array   

        return ;
        
        
    }

    // Operations 

    void enqueue( const Object & x )// Insert a new object at the back 
    {
        if( theSize == theCapacity ) reserve( 2 * theCapacity + 1 ) ;

        objects[ back ] = x ; 

        back = (back+1) % theCapacity ;

        theSize++ ;
    }

    void jump( const Object & x )// Insert a new object at the front 
    {
        // Implement this 

        if( theSize == theCapacity) // if not, there must be space between front and back
        {

          reserve(2 * theCapacity + 1) ; // increases capacity to accomodate. array is not wrapped now

        }

        front = (theCapacity - ( (theCapacity - front) % theCapacity)) - 1 ;
        // if front is zero, front is the theCapacity - 1. If front is any other # it's just -1

        objects[front] = x ; // assigns front to dereferenced pointer

        return ;
    
    }


    Object dequeue( ) // Remove and return the object at the front 
    {
        theSize-- ;

        Object temp = objects[front] ;

        front = (front+1) % theCapacity ;

        return temp ;
    }


    Object eject( ) // Remove and return the object at the back 
    {

        int ejectIndex = (theCapacity - ( (theCapacity - back) % theCapacity)) - 1 ; // decreases back index modularly
        // This works to decrement a back index of zero to the last element in the array
        // will simply decrement back - 1 if back does not equal 0 
        

        Object element = objects[ejectIndex] ; // stores value in temporary variable

        objects[ejectIndex] = 0 ; // my "empty" value

        theSize-- ; // decrease size to account for removed element

        back = ejectIndex ; // new back is where the element was ejected

        return element ;

    }

    void display() const // print out the contents of the deque
    {
       
      cout << "size = " << theSize ;
      cout << ", front = " << front << ", back = " << back << endl; // prints size variable

      cout << "< " ; // prints opening bracket
      
      int i = front ; // starts at first element in list at index front
      int j = 0; // tracks size

      while( j < theSize )
      {

        cout << i << " = " << objects[i] ;  // prints index and object assigned
        
        if( j != theSize-1 ) 
        {
            
        cout << ", " ;   // prints comma and space if we ARENT at the last item in list

        }
        
        i = (i + 1) % theCapacity ;  // increments i and resets to zero if at last index
        j++ ; // increments j

      }

      cout << " >" << endl ; // closing bracket

    }


    void ddisplay() const // print out the contents of the objects 
    // array, and relevant variables, for debugging or verifying 
    // correctness. 
    {
        
      int i = 0; // index tracker for objects array

      cout << "capacity = " << theCapacity << ", size = " << theSize;
      cout << ", front = " << front << ", back = " << back << endl;
      // prints variables for capacity and size

      cout << "[" ; // prints openening bracket
      
      while( i < theCapacity ) 
      {

        cout << i << " = " << objects[i] ;
        
        if( i != theCapacity-1 ) // removes the extra comma and space at the end
        {
        
          cout << ", " ; // prints value of each variable

        }

        i++ ;

      }

      cout << "]" << endl ; // prints closing bracket

    }


  private:
    int theSize;
    int front;
    int back;
    int theCapacity;
    int reserved; // added to track how much theCapcity has increased
    Object* objects;

};

#endif
