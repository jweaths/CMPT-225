#include "deque.h"
#include <iostream>
#include <cstring>
using namespace std;

int main( )
{

cout << endl; 

Deque<char> opTest ;

string alphabet = "abcdefghijklmnopqrztuvwxyz" ;


for( int i = 0; i < 17; i++ )  // enqueuing deque 
{

    opTest.enqueue( alphabet[i] ) ; // enqueues letters

    //cout << "12" << endl; 


}



for( int i = 0; i < 5; i++ )  // dequeuing deque 
{

    opTest.dequeue( ) ; // enqueues letters


}



for( int i = 0; i < 5; i++ )  // enqueuing deque
{

    opTest.enqueue( alphabet[i] ) ; // enqueues letters

} 

cout << "Displaying Deque 'opTest' of type Char: " << endl; ;
opTest.display() ;

cout << endl << "Displaying the Deque 'opTest' in array format: " << endl;
opTest.ddisplay() ;

cout << endl;

char testIndexChar = opTest[10] ;


cout << "opTest[10] = " << testIndexChar << endl;
cout << endl << "now assigning opTest[10] = Y" << endl;

opTest[10] = 'Y' ;

cout << "Displaying Deque 'opTest' after assigning through index" << endl;
opTest.display() ;


}
