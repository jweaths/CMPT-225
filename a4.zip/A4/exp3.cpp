#include <iostream>
#include <time.h>
#include <iomanip>
#include "ulliststr.h"
#include <string>
#include "linkedList.h"
using namespace std;

double elapsed_time( clock_t start, clock_t finish){ // returns elapsed time in microseconds 
    return (finish - start)/(double)(CLOCKS_PER_SEC/1000); 
    }
    
void clearCache() {


	const int CACHE_SIZE = 200000 ;

	int* dummy = new int[CACHE_SIZE] ;
	
	for(int i=0; i < CACHE_SIZE; i++) { // times traversal
	
		dummy[i] *= 3;
	
	}


}

int main() {

	
	// ARRAY
	
	const int SIZE = 10000 ;

	int* arr = new int[SIZE] ;
	
	cout << endl;
	
	
	
	
	for(int i=0; i < SIZE; i++) { // fills array
	
		arr[i] = 0;
	
	}
	
	
	clearCache(); // empties cache
	
	
	clock_t start = clock() ;
	
	for(int i=0; i < SIZE; i++) { // times traversal
		
		arr[i] *= 3;
		arr[i+1] *= 3;
		arr[i+2] *= 3;
		arr[i+3] *= 3;
		arr[i+4] *= 3;
		arr[i+5] *= 3;
		arr[i+6] *= 3;
		arr[i+7] *= 3;
		arr[i+8] *= 3;
		arr[i+9] *= 3;
		arr[i+10] *= 3;
		arr[i+11] *= 3;
		arr[i+12] *= 3;
		arr[i+13] *= 3;
		arr[i+14] *= 3;
		arr[i+15] *= 3;
		arr[i+16] *= 3;
		
		}
	
	clock_t end = clock() ;
	float time = elapsed_time(start, end) ;

	
	cout << "array traversal time: " << time << " milliseconds" << endl ;

	
	
	
	
	
	// LINKED LIST
	
	List* linked = new List();
	
	
	for(int i=0; i < SIZE; i++ ) { // fills linked list
	
		linked->insert(i) ;
	
	}
	
	clearCache(); // empties cache
	
	start = clock() ;
	
	
	for(int i=0; i < SIZE; i ++) { // times traversal
	
		linked->display() ; // accessing by running display function
	
	}	

	
	end = clock() ;
	time = elapsed_time(start, end) ;

	
	cout << "linked list traversal time: " << time << " milliseconds" << endl ;

	




	
	
	// UNROLLED LINKED LIST
	
	ULListStr* unrolled = new ULListStr();

	
	for(int i=0; i < SIZE; i++ ) { // fills unrolled linked list
	
		unrolled->push_back(i) ;
	
	}
	

	clearCache(); // empties cache	
	
	start = clock() ;
	
	
	for(int i=0; i < SIZE; i ++) { // times traversal
	
		unrolled->traverse() ; // accessing by popping front
	
	}
	
	
	
	end = clock() ;
	time = elapsed_time(start, end) ;

	
	cout << "unrolled linked list traversal time: " << time << " milliseconds" << endl << endl ;

	
	
	
	

	
	
		
	
	
	return 0;
	
	
	
	}
	
