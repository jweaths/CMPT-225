#include <iostream>
#include <time.h>
#include <iomanip>
using namespace std;

float elapsed_time( clock_t start, clock_t finish){ // returns elapsed time in microseconds 
    return (finish - start)/(float)(CLOCKS_PER_SEC/1000); 
    }

int main() {

// How do I know when something isn't in the cache
// there are misses

cout << endl;

const int SIZE = 1000000 ;

int* a = new int[SIZE] ;





int i = 0;

clock_t loop1Start = clock();

while(i < SIZE)  {

	a[i] *= 3;
	a[i+1] *= 3;
	a[i+2] *= 3;
	a[i+3] *= 3;
	a[i+4] *= 3;
	a[i+5] *= 3;
	a[i+6] *= 3;
	a[i+7] *= 3;
	a[i+8] *= 3;
	a[i+9] *= 3;
	a[i+10] *= 3;
	a[i+11] *= 3;
	a[i+12] *= 3;
	a[i+13] *= 3;
	a[i+14] *= 3;
	a[i+15] *= 3;
	a[i+16] *= 3;

	
	i += 64 ;

	}


clock_t loop1End = clock() ;
float loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "Loop 1 time: " << loop1Time << " milliseconds" << endl ;
delete [] a;


int* b = new int[SIZE] ;
clock_t loop2Start= clock() ;

i = 0; //resets i
while( i < SIZE ) {
	b[i] *= 3;
	i+=64 ; }
	
clock_t loop2End = clock() ;
float loop2Time = elapsed_time(loop2Start, loop2End) ;
cout << "Loop 2 time: " << loop2Time << " milliseconds" << endl ;







// Calculating Averages ---------------------------------------------

a = new int[SIZE] ;



float misses = 0;
float hits = 0;

i = 0;

while(i < SIZE)  {
	
	
	clock_t missStart = clock() ;
	a[i] *= 3;
	clock_t missEnd = clock() ;
	misses += elapsed_time(missStart, missEnd) ;
	
	clock_t hitStart = clock();
	a[i+1] *= 3;
	a[i+2] *= 3;
	a[i+3] *= 3;
	a[i+4] *= 3;
	a[i+5] *= 3;
	a[i+6] *= 3;
	a[i+7] *= 3;
	a[i+8] *= 3;
	a[i+9] *= 3;
	a[i+10] *= 3;
	a[i+11] *= 3;
	a[i+12] *= 3;
	a[i+13] *= 3;
	a[i+14] *= 3;
	a[i+15] *= 3;
	a[i+16] *= 3;
	clock_t hitsEnd = clock();
	hits += elapsed_time(hitStart, hitsEnd);
	
	i += 64 ;

	}
	

float hitsAvg = ( hits / (SIZE/64)/15 ) ; // since there's 16 hits per iteration
float missesAvg = ( misses / (SIZE/64) - hitsAvg ) ; // one miss per iteration

cout << "Average time of misses: " << missesAvg << " milliseconds" << endl;

cout << "Average time of hits: " << hitsAvg << " milliseconds" << endl << endl;


return 0;

}
