#include <iostream>
#include <time.h>
#include <iomanip>
using namespace std;

double elapsed_time( clock_t start, clock_t finish){ // returns elapsed time in milliseconds 
    return (finish - start)/(double)(CLOCKS_PER_SEC/1000); 
    }

int main() {


cout << endl;


// Array declaration

const int SIZE10 = 10; int* a = new int[SIZE10] ;
const int SIZE100 = 100; int* b = new int[SIZE100] ;
const int SIZE250 = 250 ; int* c = new int[SIZE250] ;
const int SIZE500 = 500; int* d = new int[SIZE500] ;
const int SIZE1K = 1000; int* e = new int[SIZE1K] ;
const int SIZE2500 = 2500; int* f = new int[SIZE2500] ;
const int SIZE5k = 5000; int* g = new int[SIZE5k] ;
const int SIZE7k = 7000 ; int* h = new int[SIZE7k] ;
const int SIZE10k = 10000; int* ii = new int[SIZE10k] ;
const int SIZE15K = 15000; int* j = new int[SIZE15K] ;
const int SIZE30k = 30000 ; int* k = new int[SIZE30k] ;
const int SIZE50K = 50000; int* l = new int[SIZE50K] ;
const int SIZE75k = 75000 ; int* m = new int[SIZE75k] ;
const int SIZE100k = 100000 ; int* n = new int[SIZE100k] ;
const int SIZE200K = 200000; int* o = new int[SIZE200K] ;
const int SIZE400k = 400000 ; int* p = new int[SIZE400k] ;
const int SIZE700k = 700000 ; int* q = new int[SIZE700k] ; 
const int SIZE1M = 1000000 ; int* r = new int[SIZE1M] ;
const int SIZE2M = 2000000 ; int* s = new int[SIZE2M] ;
const int SIZE4M = 4000000 ; int* t = new int[SIZE4M] ;
const int SIZE8M = 8000000 ; int* u = new int[SIZE8M] ;
const int SIZE16M = 16000000 ; int* v = new int[SIZE16M] ;
const int SIZE32M = 32000000 ; int* w = new int[SIZE32M] ;

// SIZE10

cout << "SIZE of arrays and TIME in MILLISECONDS: " << endl << endl;
clock_t loop1Start= clock() ;

for(int i=0; i < SIZE10; i += 64) {
	a[i] *= 3;
	a[i+1] *= 3;
	a[i+2] *= 3;
	a[i+3] *= 3;
	a[i+4] *= 3;
	a[i+5] *= 3;
	a[i+6] *= 3;
	a[i+7] *= 3;
	a[i+8] *= 3;
	a[i+9] *= 3;
	a[i+10] *= 3;
	a[i+11] *= 3;
	a[i+12] *= 3;
	a[i+13] *= 3;
	a[i+14] *= 3;
	a[i+15] *= 3;
	a[i+16] *= 3;
	}
	

clock_t loop1End = clock() ;
float loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 10: " << loop1Time << endl << endl ;


// SIZE100
loop1Start= clock() ;

for(int i=0; i < SIZE100; i += 64) {
	b[i] *= 3;
	b[i+1] *= 3;
	b[i+2] *= 3;
	b[i+3] *= 3;
	b[i+4] *= 3;
	b[i+5] *= 3;
	b[i+6] *= 3;
	b[i+7] *= 3;
	b[i+8] *= 3;
	b[i+9] *= 3;
	b[i+10] *= 3;
	b[i+11] *= 3;
	b[i+12] *= 3;
	b[i+13] *= 3;
	b[i+14] *= 3;
	b[i+15] *= 3;
	b[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 100: " << loop1Time << endl << endl ;


// SIZE250
loop1Start= clock() ;

for(int i=0; i < SIZE250; i += 64) {
	c[i] *= 3;
	c[i+1] *= 3;
	c[i+2] *= 3;
	c[i+3] *= 3;
	c[i+4] *= 3;
	c[i+5] *= 3;
	c[i+6] *= 3;
	c[i+7] *= 3;
	c[i+8] *= 3;
	c[i+9] *= 3;
	c[i+10] *= 3;
	c[i+11] *= 3;
	c[i+12] *= 3;
	c[i+13] *= 3;
	c[i+14] *= 3;
	c[i+15] *= 3;
	c[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 250: " << loop1Time << endl << endl ;


// SIZE500
loop1Start= clock() ;

for(int i=0; i < SIZE500; i += 64) {
	d[i] *= 3;
	d[i+1] *= 3;
	d[i+2] *= 3;
	d[i+3] *= 3;
	d[i+4] *= 3;
	d[i+5] *= 3;
	d[i+6] *= 3;
	d[i+7] *= 3;
	d[i+8] *= 3;
	d[i+9] *= 3;
	d[i+10] *= 3;
	d[i+11] *= 3;
	d[i+12] *= 3;
	d[i+13] *= 3;
	d[i+14] *= 3;
	d[i+15] *= 3;
	d[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 500: " << loop1Time << endl << endl ;


// SIZE1K
loop1Start= clock() ;

for(int i=0; i < SIZE1K; i += 64) {
	e[i] *= 3;
	e[i+1] *= 3;
	e[i+2] *= 3;
	e[i+3] *= 3;
	e[i+4] *= 3;
	e[i+5] *= 3;
	e[i+6] *= 3;
	e[i+7] *= 3;
	e[i+8] *= 3;
	e[i+9] *= 3;
	e[i+10] *= 3;
	e[i+11] *= 3;
	e[i+12] *= 3;
	e[i+13] *= 3;
	e[i+14] *= 3;
	e[i+15] *= 3;
	e[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 1K: " << loop1Time << endl << endl ;


// SIZE2500
loop1Start= clock() ;

for(int i=0; i < SIZE2500; i += 64) {
	f[i] *= 3;
	f[i+1] *= 3;
	f[i+2] *= 3;
	f[i+3] *= 3;
	f[i+4] *= 3;
	f[i+5] *= 3;
	f[i+6] *= 3;
	f[i+7] *= 3;
	f[i+8] *= 3;
	f[i+9] *= 3;
	f[i+10] *= 3;
	f[i+11] *= 3;
	f[i+12] *= 3;
	f[i+13] *= 3;
	f[i+14] *= 3;
	f[i+15] *= 3;
	f[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 2500: " << loop1Time << endl << endl ;


// SIZE5k
loop1Start= clock() ;

for(int i=0; i < SIZE5k; i += 64) {
	g[i] *= 3;
	g[i+1] *= 3;
	g[i+2] *= 3;
	g[i+3] *= 3;
	g[i+4] *= 3;
	g[i+5] *= 3;
	g[i+6] *= 3;
	g[i+7] *= 3;
	g[i+8] *= 3;
	g[i+9] *= 3;
	g[i+10] *= 3;
	g[i+11] *= 3;
	g[i+12] *= 3;
	g[i+13] *= 3;
	g[i+14] *= 3;
	g[i+15] *= 3;
	g[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 5K: " << loop1Time << endl << endl ;


// SIZE7k
loop1Start= clock() ;

for(int i=0; i < SIZE7k; i += 64) {
	h[i] *= 3;
	h[i+1] *= 3;
	h[i+2] *= 3;
	h[i+3] *= 3;
	h[i+4] *= 3;
	h[i+5] *= 3;
	h[i+6] *= 3;
	h[i+7] *= 3;
	h[i+8] *= 3;
	h[i+9] *= 3;
	h[i+10] *= 3;
	h[i+11] *= 3;
	h[i+12] *= 3;
	h[i+13] *= 3;
	h[i+14] *= 3;
	h[i+15] *= 3;
	h[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 7K: " << loop1Time << endl << endl ;


// SIZE10k
loop1Start= clock() ;

for(int i=0; i < SIZE10k; i += 64) {
	ii[i] *= 3;
	ii[i+1] *= 3;
	ii[i+2] *= 3;
	ii[i+3] *= 3;
	ii[i+4] *= 3;
	ii[i+5] *= 3;
	ii[i+6] *= 3;
	ii[i+7] *= 3;
	ii[i+8] *= 3;
	ii[i+9] *= 3;
	ii[i+10] *= 3;
	ii[i+11] *= 3;
	ii[i+12] *= 3;
	ii[i+13] *= 3;
	ii[i+14] *= 3;
	ii[i+15] *= 3;
	ii[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 10K: " << loop1Time << endl << endl ;


// SIZE15k
loop1Start= clock() ;

for(int i=0; i < SIZE15K; i += 64) {
	j[i] *= 3;
	j[i+1] *= 3;
	j[i+2] *= 3;
	j[i+3] *= 3;
	j[i+4] *= 3;
	j[i+5] *= 3;
	j[i+6] *= 3;
	j[i+7] *= 3;
	j[i+8] *= 3;
	j[i+9] *= 3;
	j[i+10] *= 3;
	j[i+11] *= 3;
	j[i+12] *= 3;
	j[i+13] *= 3;
	j[i+14] *= 3;
	j[i+15] *= 3;
	j[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 15K: " << loop1Time << endl << endl ;

// SIZE30k
loop1Start= clock() ;

for(int i=0; i < SIZE30k; i += 64) {
	k[i] *= 3;
	k[i+1] *= 3;
	k[i+2] *= 3;
	k[i+3] *= 3;
	k[i+4] *= 3;
	k[i+5] *= 3;
	k[i+6] *= 3;
	k[i+7] *= 3;
	k[i+8] *= 3;
	k[i+9] *= 3;
	k[i+10] *= 3;
	k[i+11] *= 3;
	k[i+12] *= 3;
	k[i+13] *= 3;
	k[i+14] *= 3;
	k[i+15] *= 3;
	k[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 30K: " << loop1Time << endl << endl ;



// SIZE50K
loop1Start= clock() ;

for(int i=0; i < SIZE50K; i += 64) {
	l[i] *= 3;
	l[i+1] *= 3;
	l[i+2] *= 3;
	l[i+3] *= 3;
	l[i+4] *= 3;
	l[i+5] *= 3;
	l[i+6] *= 3;
	l[i+7] *= 3;
	l[i+8] *= 3;
	l[i+9] *= 3;
	l[i+10] *= 3;
	l[i+11] *= 3;
	l[i+12] *= 3;
	l[i+13] *= 3;
	l[i+14] *= 3;
	l[i+15] *= 3;
	l[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 50K: " << loop1Time << endl << endl ;


// SIZE75k
loop1Start= clock() ;

for(int i=0; i < SIZE75k; i += 64) {
	m[i] *= 3;
	m[i+1] *= 3;
	m[i+2] *= 3;
	m[i+3] *= 3;
	m[i+4] *= 3;
	m[i+5] *= 3;
	m[i+6] *= 3;
	m[i+7] *= 3;
	m[i+8] *= 3;
	m[i+9] *= 3;
	m[i+10] *= 3;
	m[i+11] *= 3;
	m[i+12] *= 3;
	m[i+13] *= 3;
	m[i+14] *= 3;
	m[i+15] *= 3;
	m[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 75K: " << loop1Time << endl << endl ;



// SIZE100k
loop1Start= clock() ;

for(int i=0; i < SIZE100k; i += 64) {
	n[i] *= 3;
	n[i+1] *= 3;
	n[i+2] *= 3;
	n[i+3] *= 3;
	n[i+4] *= 3;
	n[i+5] *= 3;
	n[i+6] *= 3;
	n[i+7] *= 3;
	n[i+8] *= 3;
	n[i+9] *= 3;
	n[i+10] *= 3;
	n[i+11] *= 3;
	n[i+12] *= 3;
	n[i+13] *= 3;
	n[i+14] *= 3;
	n[i+15] *= 3;
	n[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 100K: " << loop1Time << endl << endl ;



// SIZE200k
loop1Start= clock() ;

for(int i=0; i < SIZE200K; i += 64) {
	o[i] *= 3;
	o[i+1] *= 3;
	o[i+2] *= 3;
	o[i+3] *= 3;
	o[i+4] *= 3;
	o[i+5] *= 3;
	o[i+6] *= 3;
	o[i+7] *= 3;
	o[i+8] *= 3;
	o[i+9] *= 3;
	o[i+10] *= 3;
	o[i+11] *= 3;
	o[i+12] *= 3;
	o[i+13] *= 3;
	o[i+14] *= 3;
	o[i+15] *= 3;
	o[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 200K: " << loop1Time << endl << endl  ;



// SIZE400k
loop1Start= clock() ;

for(int i=0; i < SIZE400k; i += 64) {
	p[i] *= 3;
	p[i+1] *= 3;
	p[i+2] *= 3;
	p[i+3] *= 3;
	p[i+4] *= 3;
	p[i+5] *= 3;
	p[i+6] *= 3;
	p[i+7] *= 3;
	p[i+8] *= 3;
	p[i+9] *= 3;
	p[i+10] *= 3;
	p[i+11] *= 3;
	p[i+12] *= 3;
	p[i+13] *= 3;
	p[i+14] *= 3;
	p[i+15] *= 3;
	p[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 400K: " << loop1Time << endl << endl ;



// SIZE700k
loop1Start= clock() ;

for(int i=0; i < SIZE700k; i += 64) {
	q[i] *= 3;
	q[i+1] *= 3;
	q[i+2] *= 3;
	q[i+3] *= 3;
	q[i+4] *= 3;
	q[i+5] *= 3;
	q[i+6] *= 3;
	q[i+7] *= 3;
	q[i+8] *= 3;
	q[i+9] *= 3;
	q[i+10] *= 3;
	q[i+11] *= 3;
	q[i+12] *= 3;
	q[i+13] *= 3;
	q[i+14] *= 3;
	q[i+15] *= 3;
	q[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 700K: " << loop1Time << endl << endl ;



// SIZE1M
loop1Start= clock() ;

for(int i=0; i < SIZE1M; i += 64) {
	r[i] *= 3;
	r[i+1] *= 3;
	r[i+2] *= 3;
	r[i+3] *= 3;
	r[i+4] *= 3;
	r[i+5] *= 3;
	r[i+6] *= 3;
	r[i+7] *= 3;
	r[i+8] *= 3;
	r[i+9] *= 3;
	r[i+10] *= 3;
	r[i+11] *= 3;
	r[i+12] *= 3;
	r[i+13] *= 3;
	r[i+14] *= 3;
	r[i+15] *= 3;
	r[i+16] *= 3;
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 1M: " << loop1Time << endl << endl ;

// SIZE2M
loop1Start= clock() ;

for(int i=0; i < SIZE2M; i += 64) {
	s[i] *= 3;
	s[i+1] *= 3;
	s[i+2] *= 3;
	s[i+3] *= 3;
	s[i+4] *= 3;
	s[i+5] *= 3;
	s[i+6] *= 3;
	s[i+7] *= 3;
	s[i+8] *= 3;
	s[i+9] *= 3;
	s[i+10] *= 3;
	s[i+11] *= 3;
	s[i+12] *= 3;
	s[i+13] *= 3;
	s[i+14] *= 3;
	s[i+15] *= 3;
	s[i+16] *= 3;
	
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 2M: " << loop1Time << endl << endl ;

// SIZE4M
loop1Start= clock() ;

for(int i=0; i < SIZE4M; i += 64) {
	t[i] *= 3;
	t[i+1] *= 3;
	t[i+2] *= 3;
	t[i+3] *= 3;
	t[i+4] *= 3;
	t[i+5] *= 3;
	t[i+6] *= 3;
	t[i+7] *= 3;
	t[i+8] *= 3;
	t[i+9] *= 3;
	t[i+10] *= 3;
	t[i+11] *= 3;
	t[i+12] *= 3;
	t[i+13] *= 3;
	t[i+14] *= 3;
	t[i+15] *= 3;
	t[i+16] *= 3;
	
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 4M: " << loop1Time << endl << endl ;

// SIZE8M
loop1Start= clock() ;

for(int i=0; i < SIZE8M; i += 64) {
	u[i] *= 3;
	u[i+1] *= 3;
	u[i+2] *= 3;
	u[i+3] *= 3;
	u[i+4] *= 3;
	u[i+5] *= 3;
	u[i+6] *= 3;
	u[i+7] *= 3;
	u[i+8] *= 3;
	u[i+9] *= 3;
	u[i+10] *= 3;
	u[i+11] *= 3;
	u[i+12] *= 3;
	u[i+13] *= 3;
	u[i+14] *= 3;
	u[i+15] *= 3;
	u[i+16] *= 3;
	
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 8M: " << loop1Time << endl << endl ;

// SIZE16M
loop1Start= clock() ;

for(int i=0; i < SIZE16M; i += 64) {
	v[i] *= 3;
	v[i+1] *= 3;
	v[i+2] *= 3;
	v[i+3] *= 3;
	v[i+4] *= 3;
	v[i+5] *= 3;
	v[i+6] *= 3;
	v[i+7] *= 3;
	v[i+8] *= 3;
	v[i+9] *= 3;
	v[i+10] *= 3;
	v[i+11] *= 3;
	v[i+12] *= 3;
	v[i+13] *= 3;
	v[i+14] *= 3;
	v[i+15] *= 3;
	v[i+16] *= 3;
	
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 16M: " << loop1Time << endl << endl ;


// SIZE32M
loop1Start= clock() ;

for(int i=0; i < SIZE32M; i += 64) {
	w[i] *= 3;
	w[i+1] *= 3;
	w[i+2] *= 3;
	w[i+3] *= 3;
	w[i+4] *= 3;
	w[i+5] *= 3;
	w[i+6] *= 3;
	w[i+7] *= 3;
	w[i+8] *= 3;
	w[i+9] *= 3;
	w[i+10] *= 3;
	w[i+11] *= 3;
	w[i+12] *= 3;
	w[i+13] *= 3;
	w[i+14] *= 3;
	w[i+15] *= 3;
	w[i+16] *= 3;
	
	}
	

loop1End = clock() ;
loop1Time = elapsed_time(loop1Start, loop1End) ;
cout << "SIZE 32M: " << loop1Time << endl << endl ;


return 0;

}




