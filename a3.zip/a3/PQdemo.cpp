#include "PQ.h"

#include <vector>
#include <algorithm>
#include <iostream>

#include "AvlTree.h"
#include "dsexceptions.h"


int main() {


cout << endl;



vector<int> tasks = {9, 7, 6, 4, 29, 8, 20, 70, 80, 90, 100} ;
vector<int> priors = {7, 3, 3, 10, 1, 21, 31, 12, 80, 2, 11} ;

PQ<int>PQ1;

cout << "--------------------------------------------------------------" << endl;

PQ<int>* PQ2 = new PQ<int>(tasks, priors) ;

cout << "PQ2: constructor" << endl;

PQ2->printPQ() ;



cout << "PQ2: insert task 11, priority 1" << endl;

PQ2->insert(11, 1) ;

PQ2->printPQ() ;



cout << "PQ2: update task 11 to priority 21" << endl;

PQ2->updatePriority(11, 21) ;

PQ2->printPQ() ;




cout << "PQ2: insert task 12 priority 33 into PQ2 via updatePriority()" << endl;

PQ2->updatePriority(12, 33) ;

PQ2->printPQ() ;




cout << "PQ2: find the minimum ID" << endl;

int minimumID = PQ2->findMin() ;

cout << "Minimum ID: " << minimumID << endl ;

PQ2->printPQ() ;




cout << "PQ2: delete the minimum element ( part 1)" << endl;

minimumID = PQ2->deleteMin() ;

cout << "ID Removed: " << minimumID << endl ;

PQ2->printPQ() ;




cout << "PQ2: delete the minimum element (part 2)" << endl;

minimumID = PQ2->deleteMin() ;

cout << "ID Removed: " << minimumID << endl ;

PQ2->printPQ() ;




cout << "PQ2: delete the minimum element (part 3)" << endl;

minimumID = PQ2->deleteMin() ;

cout << "ID Removed: " << minimumID << endl ;

PQ2->printPQ() ;




cout << "PQ2: Make the PQ empty" << endl;

PQ2->makeEmpty() ;

PQ2->printPQ() ;



return 0;



}
