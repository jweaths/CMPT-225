#ifndef PQ_H
#define PQ_H


#include <vector>
#include <algorithm>
#include <iostream>
#include <cmath>

#include "AvlTree.h"
#include "dsexceptions.h"

using namespace std;

// PQ class
// parent must be greater than child
template <typename ID>
class PQ
{

  private:

  //Data Members

  int theSize ; // tracks the size

  AvlTree<ID> avl;
  vector<int> priors;
  vector<AvlNode*> pointers;




  public:

    // Constructor
    // Initializes a new empty PQ
    PQ()
    {

   	theSize = 0 ;

    }

    PQ( const std::vector<ID> & tasks, const std::vector<int> & priorities )
	{

		theSize = 0 ;

		long unsigned int i = 0 ;

		while( i < priorities.size() || i < tasks.size() )
		{

			insert(tasks[i], priorities[i]) ;

			i++ ;

		}

	}

	void printPQ() {

		int i = 0;

		cout << "--------------------------------------------------------------" << endl;

		cout << "Size = " << size() << endl << endl;

		if( theSize > 0 ) {

			cout << "Index" << "     " << "ID" << "     " << "Priors:" << "     " << "Pointers:" << endl;

			while( i < theSize ) {

				cout << i << "         " << (pointers[i])->element << "     " << priors[i] << "        " << pointers[i] << endl;
				i++ ;

			}

		}

		else
			cout << "Heap:" << endl << "Empty heap" << endl;

		cout << endl;

		cout << "Tree:" << endl;

		avl.printTree() ;


		if( theSize > 0 ) {

			cout<< endl << "Min ID:" << endl;

			cout << findMin() << endl;

		}


	    cout << "--------------------------------------------------------------" << endl;

	}


	int parent(int i) // helper function finds parent node
  	{

  		int position = floor(i/ 2) ;

  		return position ;

  	}

  	int leftC(int i) // helper function finds left child in array
  	{


  		int position = (2 * i) + 1 ;
  		return position ;

  	}


  	int rightC(int i) // helper function finds right child in array
  	{


  		int position = (2 * i) + 2 ;
  		return position ;

  	}

  	// int successor(int i) { // helper function finds succesor in array or the same if it's the largest element

  	// 	// i is the index of current


	// 	int rightI = rightC(i) ;
	// 	int leftI = leftC(i) ;


	// 	if(leftI > theSize ) { // if you can't go any more left

	// 	return i ; // return current node ( the sucessor of original call)

  	// 	}

	// 	else if( rightI < theSize && leftC(rightI) < theSize ) { // if current has a right child and rc has lc


	// 		return successor(rightI) ; // go right

	// 	}

	// 	else if( leftI < theSize ) { // if the node has a left child

	// 		return successor(leftI) ; // go left

	// 	}

	// 	return i;

  	// }

  	void theSwap(int i1, int i2) { // swaps two items in priors given the index

  		int temp = priors[i1] ; // stores first objects
  		AvlNode* temp2 = pointers[i1] ; //

  		priors[i1] = priors[i2] ; // assigns first index to second object
  		pointers[i1] = pointers[i2] ; //

  		(pointers[i1])->index = i2 ; // swaps indexes in avl
  		(pointers[i2])->index = i1 ; //

  		priors[i2] = temp ; // assigns second index to first object
  		pointers[i2] = temp2 ; //

  	}


  	void percolate_up(int i) // brings element up heap until parent is less than
  	{
  		// current index is just i
  		int current = priors[i] ;

		int parentI = parent(i) ;
  		int parent = priors[parentI] ;

  		if(current >= parent) {	// if current node is less than parent

  			return;

  			}
  		else if(current <= parent) {	// if current node is less than parent

			theSwap(i, parentI) ; // current swaps up
			current = parentI ; // position is reflected ;
			percolate_up(current) ; // recursive call

			}


  	}

  	// index where item was just inserted is used
  	void percolate_down(int i) // bring element down the heap until child is greater than i
  	{

		//////////////////////////////// percolate up first
  		int current = priors[i] ;

		int parentI = parent(i) ;
  		int parent = priors[parentI] ;


  		if(current <= parent) {	// if current node is less than parent

			theSwap(i, parentI) ; // current swaps up
			current = parentI ; // position is reflected ;
			percolate_up(current) ; // recursive call

			}


  		//////////////////////////////// now percolate down

		int rightI =  (2 * i) + 2 ;
		int leftI = (2 * i) + 1 ;
		int rightChild;
		int leftChild;

		if( rightI < theSize ) // prevents accessing non-existent children
			rightChild = priors[rightI] ;

		if( leftI < theSize ) // prevents accessing non-existent children
			leftChild = priors[leftI] ;



		if( current <= rightChild && current <= leftChild && i < theSize && current >= parent ) // base case - current is less than children
			return ;


		else if( leftChild <= rightChild && leftI < theSize ) // if left child is less
		{

				theSwap(i, leftI) ;
				percolate_down(leftI) ;
				return ;



		}
		else if (leftChild >= rightChild && rightI < theSize )// if right child is less
		{

				theSwap(i, rightI) ;
				percolate_down(rightI) ;
				return ;

		}

  	}


	// Insert ID x with priority p.
    void insert( const ID & x, int p ) {


    	int i = theSize ; // index of insertion

    	priors.push_back( p ) ; // insert priority into priors


    	pointers.push_back( avl.insert( x, size() ) ) ; // insert task into tree and return node

    	percolate_up( i ) ; // percolates up the element that was just inserted and returns value


    	theSize++ ; // increment the size to the new empty insertion index

    }


    // Return the number of task IDs in the queue
    int size() const {


    	int size = theSize ;

    	return size ;

    }


    // Emptiness check
    bool isEmpty( ) const  {


    	if( size() == 0 )
    		return true;


    	else
    		return false;


    }

    // Update the priority of ID x to p
    //    Inserts x with p if x not already in the queue
    void updatePriority( const ID & x, int p ) {

    	int i = 0 ; // cursor
    	bool inside = false; // confirms x in queue
		int rightI =  (2 * i) + 2 ;
		int leftI = (2 * i) + 1 ;

    	AvlNode* t = avl.contains(x, p) ; // check if x contains x and returns pointer

    	while( i < size() || inside == false )
    	{

			if( pointers[i] == t ) // if pointer was found
			{

				priors[i] = p; // updates priority

				inside = true;  // was found

				if( priors[i] <= priors[parent(i)] ) {

					percolate_up(i) ;
					return ;

				}

				if(rightI < theSize) {

					if( priors[i] >= priors[rightI] ) {

						percolate_down(i) ;
						return ;

						}
					}

				if(leftI < theSize) {

					if( priors[i ] >= priors[leftI] ) {

						percolate_down(i) ;
						return ;
						}
					}

				}

			i++ ;
    	}

    	if(inside == false) // if pointer was not found
    	{
    		priors.push_back( p ) ; // insert priority into priors
    		pointers.push_back( avl.insert( x, theSize ) ) ; // insert task into tree and return node

			t = avl.insert( x, p ); // inserts x w/ priority into PQ

			if(rightI < theSize) {

					if( priors[i] >= priors[rightI] ) {

						percolate_down(i) ;
						return ;

					}
				}

			if(leftI < theSize) {

					if( priors[i ] >= priors[leftI] ) {

						percolate_down(i) ;
						return ;

					}

				}
    	}

    }


    // Returns an ID with minimum priority without removing it
    //     Throws exception if queue is empty

    const int & findMin() const {

    	int i = 0; // index used for min search
    	int min = 0; // used for reference
    	const int & minRef = min; // passes reference

    	if (isEmpty())
    		throw UnderflowException{} ;


    	else {

    		min = (pointers[i])->element ; // finds the element in the tree

    		return minRef ; // returns the reference

    		}

    }



      // Deletes and Returns a task ID with minimum priority
    //    Throws exception if queue is empty
    const ID & deleteMin()  {


		int i = 0 ;
		ID minID = findMin() ; // finds min priority
		const ID & minRef = minID ;  // passes reference

		avl.remove(minID) ; // remove the min ID from the tree

		priors[i] = priors[theSize-1] ;
		pointers[i] = pointers[theSize-1] ;

		theSize-- ;

		percolate_down(i) ;




		return minRef ;


    }



    // Delete all IDs from the PQ
    void makeEmpty( ) {

		priors.clear(); // clears the heap
		pointers.clear();

		avl.makeEmpty(); // clears the tree

		theSize = 0; // resets the size

    }

};
#endif
